# Screen Map: a Claude Skill

By [Ali Mahmoud (TheGlocalPM)](https://theglocalpm.com). Free to use, edit and make your own.

Screen Map turns a product spec into a **one-page, clickable map of every screen in the product**. The map shows what screens exist, how a user moves through them, which ones are in the MVP, and which few reusable layouts they're built from. Click any screen to get a **complete design prompt** for it, ready to paste into an AI design tool.

It's useful when you're scoping a product and want to see its size before anyone designs or builds anything. Most products turn out to have 40–60 screens that are built from only 6–9 layouts.

## What's in the folder

| File | What it is |
|---|---|
| `SKILL.md` | The instructions Claude follows: when to use the skill, a 10-step process, and rules. |
| `template.html` | The page code. You fill in the `CONFIG` object and the design tokens and leave the rest alone. |
| `README.md` | This file. |

## Install

Unzip the folder into your Claude skills directory so it looks like this:

```
~/.claude/skills/screen-map/SKILL.md
~/.claude/skills/screen-map/template.html
~/.claude/skills/screen-map/README.md
```

Claude Code picks the skill up automatically. It needs `template.html` next to `SKILL.md` to work.

## Use it

In Claude Code, run `/screen-map` or ask in plain words:

> "Build a screen map for this product."
> "How many screens does this app have? Show me."

For good results, have **a written spec** in the project, such as a feature list, module spec, design notes or decisions log. Every screen on the map must trace back to the spec, and the skill won't invent features to fill the map.

Claude will then:

1. Read your spec and design docs.
2. List every screen a user actually lands on, including the ones people often forget: login, onboarding, notifications, settings and admin.
3. Group the screens into 6–12 areas, organised the way a user thinks about the product.
4. Give each screen one of 5–9 reusable layouts and draw a small wireframe of each layout.
5. Mark each screen **MVP**, **Later** or **Staff**. If you haven't decided the MVP, it says the marking is a proposal.
6. Draw the main user path in 3–6 phases.
7. Style the page in your project's design system, or propose one if you don't have one.
8. Write a full design prompt for every screen.
9. Save the page as `<project>/design/screen-map.html`. If your setup can publish Claude Artifacts, it also publishes the page and gives you a link.

When the scope changes, say "update the screen map". Claude edits the same file (and the same link, if it was published).

## What the page shows

- **Stat tiles:** total screens, MVP count, layouts and staff-only screens. The page counts these from the data.
- **Filters** by status and by layout.
- **Screen cards** grouped by area. Click a card to see what the user does there, which spec section it comes from, and its design prompt with a **Copy prompt** button.
- **Main path:** the user's journey, with each step linked to its card.
- **Layouts:** the few page patterns that every screen reuses.
- **Design language** (optional): colour roles, type, signature components, and the principles borrowed from established design systems.

It supports light and dark themes, keyboard navigation and reduced motion, and it works at phone width.

## Filling the template by hand

1. Replace `{{PROJECT}}` in `<title>`.
2. Swap the Google Fonts `<link>` for your project's fonts.
3. Change the *values* (not the names) of the CSS colour variables in **all three** theme blocks.
4. Fill in `CONFIG` at the bottom of the file:

```js
const CONFIG = {
  eyebrow: "Acme Leads · draft",
  title: "Every screen in Acme Leads, on one page",
  intro: "One or two plain sentences. Say if the MVP marking is a proposal.",
  statuses: {                       // key → label, lozenge colour, card edge
    mvp:   {label:"MVP candidate", loz:"accent",  edge:"accent"},
    later: {label:"Later",         loz:"neutral", edge:"dashed"},
    admin: {label:"Staff",         loz:"staff",   edge:"staff"}
  },
  statTiles: [["total","screens"],["mvp","MVP candidate"],["layouts","reusable layouts"]],
  promptLabel: "In design spec",    // null hides the "already specified" dot
  brief: {                          // shared by every design prompt; null hides the prompts
    product: "Acme Leads",
    context: "What it is, who it's for, its core rule, the feeling it must give.",
    system: "Colours (light + dark hex), fonts, spacing, radius, components, copy tone.",
    shell: "Sidebar items and top bar.",
    shellStaff: "How the staff/admin area differs.",
    rules: "Fictional sample data, accessibility, language/RTL rules."
  },
  specs: {                          // one per screen name
    "Leads list": {who:"Sales rep", el:"Every element with sample data and exact button labels.", states:"Empty; loading; error.", m:true, rtl:false}
  },
  layouts: {                        // key → name, description, layout guidance, 120×80 SVG using CSS vars
    table: {name:"Table with filters", desc:"Filter bar, sortable columns.", pattern:"Header, filter bar, dense table, bulk actions.", svg:'<rect .../>'}
  },
  areas: [                          // items: [name, layoutKey, statusKey, inSpec 0|1, what it does, spec ref]
    {id:"leads", name:"Leads", alt:"", items:[
      ["Leads list","table","mvp",1,"Filter and sort every lead the system found.","spec §3.1"]
    ]}
  ],
  flow: [["Find",["Leads list"]]],  // names must match item names exactly
  initialSelection: "Leads list",
  designLanguage: null              // or {eyebrow, title, intro, swatches, typeHtml, componentsHtml, borrow, note}
};
```

**Lozenge colours:** `accent`, `staff`, `neutral`, `good`, `crit`, `attn`. **Card edges:** `accent`, `staff`, `dashed`, `plain`.

## Rules worth knowing

- Each screen description is one plain sentence about what the user *does* there.
- Don't type counts into the intro. The page computes them, and a typed number can end up contradicting the data.
- Main-path names must match card names exactly. If one doesn't, the page shows a red **"Missing: …"** lozenge.
- Amber (`attn`) is only for "a human must act", and staff purple is only for admin screens.
- Sample data in the design prompts is fictional. Never use real people or companies presented as real.
- When the page borrows from Carbon, Atlassian, Polaris, Material 3 and similar systems, it takes their principles only, never their branding.
